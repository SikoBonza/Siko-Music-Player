import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

void main() => runApp(const SikoMusicPlayer());

class SikoMusicPlayer extends StatelessWidget {
  const SikoMusicPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF1769AA);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Siko Music Player',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF4F8FC),
        useMaterial3: true,
      ),
      home: const PlayerHome(),
    );
  }
}

class Track {
  Track({required this.title, required this.path, this.artist = 'Unknown artist'});
  final String title;
  final String path;
  final String artist;
}

class PlayerHome extends StatefulWidget {
  const PlayerHome({super.key});
  @override
  State<PlayerHome> createState() => _PlayerHomeState();
}

class _PlayerHomeState extends State<PlayerHome> {
  final AudioPlayer _player = AudioPlayer();
  final List<Track> _tracks = [];
  final Set<String> _favourites = {};
  final TextEditingController _search = TextEditingController();
  int _selectedIndex = 0;
  int _currentIndex = -1;
  bool _isPlaying = false;
  String _category = 'All music';

  @override
  void initState() {
    super.initState();
    _player.playerStateStream.listen((state) {
      if (mounted) setState(() => _isPlaying = state.playing);
    });
    _player.currentIndexStream.listen((index) {
      if (mounted && index != null) setState(() => _currentIndex = index);
    });
  }

  @override
  void dispose() {
    _search.dispose();
    _player.dispose();
    super.dispose();
  }

  Future<void> _addMusic() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      allowMultiple: true,
    );
    if (result == null) return;
    final added = result.files.where((f) => f.path != null).map((f) {
      final name = f.name.replaceAll(RegExp(r'\.[^.]+$'), '');
      return Track(title: name, path: f.path!);
    }).toList();
    setState(() {
      for (final track in added) {
        if (!_tracks.any((t) => t.path == track.path)) _tracks.add(track);
      }
    });
    if (_tracks.isNotEmpty && _currentIndex == -1) {
      await _playTrack(0);
    }
  }

  Future<void> _playTrack(int index) async {
    if (index < 0 || index >= _tracks.length) return;
    try {
      await _player.setAudioSource(
        AudioSource.uri(Uri.file(_tracks[index].path)),
      );
      await _player.play();
      setState(() => _currentIndex = index);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sorry, this audio file could not be played.')),
      );
    }
  }

  Future<void> _togglePlay() async {
    if (_tracks.isEmpty) {
      await _addMusic();
      return;
    }
    if (_isPlaying) {
      await _player.pause();
    } else if (_currentIndex >= 0) {
      await _player.play();
    } else {
      await _playTrack(0);
    }
  }

  Future<void> _next() async {
    if (_tracks.isEmpty) return;
    await _playTrack((_currentIndex + 1) % _tracks.length);
  }

  Future<void> _previous() async {
    if (_tracks.isEmpty) return;
    await _playTrack(_currentIndex <= 0 ? _tracks.length - 1 : _currentIndex - 1);
  }

  List<Track> get _visibleTracks {
    final q = _search.text.trim().toLowerCase();
    return _tracks.where((t) {
      final matchesSearch = t.title.toLowerCase().contains(q) ||
          t.artist.toLowerCase().contains(q);
      final matchesFavourite = _selectedIndex != 2 || _favourites.contains(t.path);
      return matchesSearch && matchesFavourite;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final current = _currentIndex >= 0 && _currentIndex < _tracks.length
        ? _tracks[_currentIndex]
        : null;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Row(children: [
          Icon(Icons.music_note_rounded, color: Color(0xFF1769AA), size: 30),
          SizedBox(width: 8),
          Text('Siko Music Player', style: TextStyle(fontWeight: FontWeight.bold)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Add music from phone',
            onPressed: _addMusic,
            icon: const Icon(Icons.add_circle_outline),
          ),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: TextField(
            controller: _search,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'Search your music',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            ),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            scrollDirection: Axis.horizontal,
            children: ['All music', 'PNG / Local', 'International', 'Gospel', 'Reggae'].map((label) {
              final selected = _category == label;
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(
                  label: Text(label),
                  selected: selected,
                  onSelected: (_) => setState(() => _category = label),
                ),
              );
            }).toList(),
          ),
        ),
        Expanded(
          child: _visibleTracks.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.library_music, size: 64, color: Color(0xFF1769AA)),
                      const SizedBox(height: 12),
                      const Text('Your music library is ready', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      const Text('Add audio files from your phone to start listening.', textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      FilledButton.icon(onPressed: _addMusic, icon: const Icon(Icons.add), label: const Text('Add music')),
                    ]),
                  ),
                )
              : ListView.builder(
                  itemCount: _visibleTracks.length,
                  itemBuilder: (context, i) {
                    final track = _visibleTracks[i];
                    final originalIndex = _tracks.indexOf(track);
                    final playing = originalIndex == _currentIndex && _isPlaying;
                    final favourite = _favourites.contains(track.path);
                    return Card(
                      color: Colors.white,
                      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: const Color(0xFFE3F0FC),
                          child: Icon(playing ? Icons.equalizer : Icons.music_note, color: const Color(0xFF1769AA)),
                        ),
                        title: Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: const Text('On this phone'),
                        onTap: () => _playTrack(originalIndex),
                        trailing: IconButton(
                          icon: Icon(favourite ? Icons.favorite : Icons.favorite_border,
                              color: favourite ? Colors.red : Colors.blueGrey),
                          onPressed: () => setState(() {
                            favourite ? _favourites.remove(track.path) : _favourites.add(track.path);
                          }),
                        ),
                      ),
                    );
                  },
                ),
        ),
        if (current != null)
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
            child: Column(children: [
              Row(children: [
                const Icon(Icons.music_note, color: Color(0xFF1769AA)),
                const SizedBox(width: 10),
                Expanded(child: Text(current.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600))),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton(onPressed: _previous, icon: const Icon(Icons.skip_previous_rounded, size: 32)),
                IconButton.filled(onPressed: _togglePlay,
                    icon: Icon(_isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 30)),
                IconButton(onPressed: _next, icon: const Icon(Icons.skip_next_rounded, size: 32)),
              ]),
            ]),
          ),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (i) => setState(() => _selectedIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.library_music_outlined), label: 'Library'),
          NavigationDestination(icon: Icon(Icons.favorite_outline), selectedIcon: Icon(Icons.favorite), label: 'Favourites'),
        ],
      ),
    );
  }
}
